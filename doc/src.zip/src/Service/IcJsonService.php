<?php

namespace App\Service;

use App\Entity\IcCentroCosto;
use App\Entity\IcCentroOrganizativoDireccion;
use App\Entity\IcCuentaContable;
use App\Entity\IcDireccion;
use App\Entity\IcSolicitud;
use App\Entity\IcTipoSolicitud;
use App\Entity\IcTorneo;
use App\Entity\IcTorneoCategoria;
use App\Entity\IcTorneoJornada;
use App\Helpers\IcProfileTrait;
use Symfony\Component\HttpFoundation\JsonResponse;


class IcJsonService
{
    use IcProfileTrait;


    public function getCuentasContables()
    {
        try {
            $cuenta = $this->entityManager->getRepository(IcCuentaContable::class)
                ->getCuentaContable($this->profile()->getIdDireccion()->getIdDireccion());
            return new JsonResponse($cuenta, 200, array('Content-Type' => 'application/json'));

        } catch (\Exception $e) {
            return new JsonResponse(array('error' => 'Ocurrio un error al obtener las cuentas contables  ' . $e->getMessage()));
        }
    }

    /**
     * @param int $centro
     * @return JsonResponse
     */
    public function getListas(int $centro):JsonResponse
    {
        try {

            if ($centro == 'co') {
                $co = $this->entityManager->getRepository(IcCentroOrganizativoDireccion::class)
                    ->getFindByWhere(['idDireccion', $centro], true );

                return new JsonResponse(['co' => $co], 200, array('Content-Type' => 'application/json'));
            }

            if ($centro  == 'cc'){
                $cc = $this->entityManager->getRepository(IcCentroCosto::class)
                    ->getFindByWhere(array('idCentroOrganizativo' , $centro), true );
                return new JsonResponse(['cc' => $cc], 200, array('Content-Type' => 'application/json'));
            }

            $direccion = $this->entityManager->getRepository(IcDireccion::class)
                ->getFindByWhere(array('idDireccion' ,$this->profile()->getIdDireccion()->getIdDireccion()), true);

            return new JsonResponse(['direccion' => $direccion], 200, array('Content-Type' => 'application/json'));


        } catch (\Exception $e) {
            return new JsonResponse(['Error' => 'Al obtener la lista de centro costo, centro organizativo y direccion'],
                200, array('Content-Type' => 'application/json'));
        }
    }

    /**
     * @param int $centro
     * @return JsonResponse
     */
    public function getDireccion($direccion):JsonResponse
    {
        try {

            $data = $this->entityManager->getRepository(IcDireccion::class)
                ->getFindByWhere(array('idDireccion' , $direccion ), true);

            return new JsonResponse(['direccion' => $data], 200, array('Content-Type' => 'application/json'));


        } catch (\Exception $e) {
            return new JsonResponse(['Error' => 'Al obtener la lista de centro costo, centro organizativo y direccion'],
                200, array('Content-Type' => 'application/json'));
        }
    }


    /**
     * @param int $centroCosto
     * @return JsonResponse
     */
    public function getCentroCosto(int $centroCosto):JsonResponse //Request $request, IcCentroCostoRepository  $centroCostoRepository )
    {
        try {
            if ($centroCosto) {
                $cc = $this->entityManager->getRepository(IcCentroCosto::class)
                    ->getFindByWhere(array('idCentroOrganizativo' ,$centroCosto), true );
                return new JsonResponse(['cc' => $cc], 200, array('Content-Type' => 'application/json'));
            }

        } catch (\Exception $e) {
            return new JsonResponse(['Error' => 'Error al obgener el centro de costo'], 200, array('Content-Type' => 'application/json'));
        }
    }


    /**
     * @param int $centroOrganizativo
     * @return JsonResponse
     */
    public function getCentroOrganizativo(int $centroOrganizativo):JsonResponse
    {
        try {
            if ($centroOrganizativo) {
                $co = $this->entityManager->getRepository(IcCentroOrganizativoDireccion::class)
                    ->getFindByWhere(['idDireccion', $centroOrganizativo], true );

                return new JsonResponse(['co' => $co], 200, array('Content-Type' => 'application/json'));
            }
        } catch (\Exception $e) {
            return new JsonResponse(['ERROR' => 'Error al obtener el centro organizativo'], 200, array('Content-Type' => 'application/json'));
        }
    }

    public function getTorneoCategoriaJornada():JsonResponse
    {
        try {

            $dataTorneo     = $this->entityManager->getRepository(IcTorneo::class)->transformAll();
            $dataCategoria  = $this->entityManager->getRepository(IcTorneoCategoria::class)->transformAll();
            $dataJornada    = $this->entityManager->getRepository(IcTorneoJornada::class)->transformAll();

            return new JsonResponse(['torneo' => $dataTorneo, 'categoria' => $dataCategoria, 'jornada' => $dataJornada], 200, array('Content-Type' => 'application/json'));

        } catch (\Exception $e) {
            return new JsonResponse(['error' => 'Ocurrio un error al obtener el Torneo '], 200, array('Content-Type' => 'application/json'));
        }
    }


    public function getTipoSolicitud():JsonResponse
    {
        try {

            $solicitud = $this->entityManager->getRepository(IcTipoSolicitud::class)
            ->transformAll();
            return  new JsonResponse(['TipoSolicitud'=> $solicitud], 200, array('Content-Type' => 'application/json'));

        } catch (\Exception $e) {

            $this->addFlash('warning', 'Error al obtener las listas de solicitudes');
            return new JsonResponse(['error' => 'Ocurrio un error al obtener la lista de Solicitudes ' ],
                200, ['Content-Type' => 'application/json']);
        }
    }


    /**
     * @param  $user
     * @param  $tipoSolicitud
     * @param  $json
     * @return JsonResponse
     */
    public function getSolicitudes($user, $tipoSolicitud, $json):JsonResponse
    {
        try {
                $solicitudes = $this->entityManager->getRepository(IcSolicitud::class)
                    ->getAllSolicitudByType($user, $tipoSolicitud, $json);

            if(!$solicitudes){
                return new JsonResponse(['error'  => 'Error al procesar las solicitudes del Usuario '],
                    200, array('Content-Type' => 'application/json'));
            }
            return  new JsonResponse($solicitudes, 200, array('Content-Type' => 'application/json'));

        } catch ( \Exception $e) {
            return new JsonResponse(['error' => 'Error al procesar las solicitudes del Usuario '],
            200, array('Content-Type' => 'application/json'));
        }
    }

}
