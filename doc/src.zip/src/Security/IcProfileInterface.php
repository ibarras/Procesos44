<?php


namespace App\Security;


interface IcProfileInterface
{
    public function getProfile();

}